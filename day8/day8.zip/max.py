# max.py
def find_max(numbers):
    return max(numbers)