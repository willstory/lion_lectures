def add(x, y):    
    return x+y

def strange_func(x, y):
    if x>y:
        return x*100
    return y/5

# strange_func(10, 8) -> 1000
# strange_func(1, 8) -> 1.6
